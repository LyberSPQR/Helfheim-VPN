#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "auth.h"
#include <QMessageBox>
#include <QDir>
#include <QTextStream>
#include <QString>
#include <QStringList>
#include <QFileInfo>
#include <QFile>
#include <filesystem>
#include <QTimer>
#include <QProcess>


namespace fs = std::filesystem;

#if defined Q_OS_WIN
QString osys = "win";
#elif defined(Q_OS_LINUX)
QString osys = "lin";
#endif

MainWindow::MainWindow(QWidget *parent) : QMainWindow(parent), ui(new Ui::MainWindow) {
    ui->setupUi(this);
    ui->statusbar->setStyleSheet("color: #c1c1c1");


            openvpn_process = nullptr;
    ckclient_process = nullptr;
    QTimer *timer = new QTimer(this);
    connect(timer, &QTimer::timeout, this, &MainWindow::remainingTimeCounter);
    timer->start(600000);

}

MainWindow::~MainWindow() {
    delete ui;
    delete openvpn_process;
    delete ckclient_process;
    openvpn_process = nullptr;
    ckclient_process = nullptr;
}

void MainWindow::on_pushButton_clicked() {
    Auth authWindow;
    authWindow.setModal(true);
    authWindow.exec();

}
void MainWindow::remainingTimeCounter()
{
    std::time_t currentTime = std::time(nullptr);


            QString path = QCoreApplication::applicationFilePath();
    QFileInfo fileInfo(path);
    QString working_dir = fileInfo.absolutePath();


    QString remaining_time_path = working_dir + "/remaining_time.txt";

    QFile file(remaining_time_path);
    if (file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QTextStream in(&file);
        QString line = in.readLine();
        int remain_time = line.toInt();
        file.close();
        remain_time = (remain_time - currentTime) / 86400;
        ui->remain_time->setText(QString::number(remain_time) + " days");
    }
    // else {
    //     QMessageBox::critical(this, "Ошибка", "Не удалось определить оставшееся время");
    // }

}
void MainWindow::on_checkBox_stateChanged(int state) {
    QString path = QCoreApplication::applicationFilePath();
    QFileInfo fileInfo(path);
    QString working_dir = fileInfo.absolutePath();
    QString command = working_dir + "/config.ovpn";

    int cnt = 0;
    for (const auto& entry : fs::directory_iterator(fs::current_path())) {
        if (entry.is_regular_file() && (entry.path().extension() == ".ovpn" || entry.path().extension() == ".json")) {
            cnt++;
        }
    }

    if (cnt != 0) {
        try {
            if (state == Qt::Checked) {
                if (osys == "lin") {
                    openvpn_process = new QProcess();
                    ckclient_process = new QProcess();
                    if (!ckclient_process->startDetached("./ck-client", QStringList() << "-c" << "ckclient.json" << "-s" << "191.96.94.211")) {
                        throw std::runtime_error("Failed to start ck-client process");
                    }
                    if (!openvpn_process->startDetached("openvpn", QStringList() << command)) {
                        throw std::runtime_error("Failed to start openvpn process");
                    }
                    remainingTimeCounter();
                    ui->ip_adress->setText("191.96.94.211");
                    ui->statusbar->showMessage("VPN service is enable");
                } else if (osys == "win") {
                    openvpn_process = new QProcess();
                    ckclient_process = new QProcess();
                    if (!ckclient_process->startDetached("ck-client.exe", QStringList() << "-c" << "ckclient.json" << "-s" << "191.96.94.211")) {
                        throw std::runtime_error("Failed to start ck-client process");
                    }
                    if (!openvpn_process->startDetached("openvpn.exe", QStringList() << command)) {
                        throw std::runtime_error("Failed to start openvpn process");
                    }
                    ui->statusbar->showMessage("VPN service is enable");
                }
            } else {
                QMessageBox::StandardButton reply;
                reply = QMessageBox::question(this, "Confirmation", "Are you sure you want to disable VPN service?", QMessageBox::Yes | QMessageBox::No);

                if (reply == QMessageBox::Yes) {
                    delete openvpn_process;
                    delete ckclient_process;
                    openvpn_process = nullptr;
                    ckclient_process = nullptr;
                    ui->ip_adress->setText("No connection");
                    ui->statusbar->showMessage("VPN service is disable");
                } else {
                    ui->checkBox->setChecked(true);
                }
            }
        } catch (const std::exception& e) {
            QMessageBox::critical(this, "Error", e.what());
        }
    } else {
        if (ui->checkBox->isChecked()) {
            QMessageBox::critical(this, "Error", "You are not authenticated.");
            ui->checkBox->setCheckState(Qt::Unchecked);
        }
    }
}
